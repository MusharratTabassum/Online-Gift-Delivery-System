package com.giftsdelivery.order_info.repository;

import com.giftsdelivery.order_info.model.OrderDetail;
import org.springframework.data.repository.CrudRepository;

public interface OrderdetailsRepository extends CrudRepository <OrderDetail,Integer>{


}
