package com.giftsdelivery.giftsitems.exeption;

public class ResourceAlreadyExistsException extends Exception {
    public ResourceAlreadyExistsException() {
       super("Already Exists!");
    }
}
