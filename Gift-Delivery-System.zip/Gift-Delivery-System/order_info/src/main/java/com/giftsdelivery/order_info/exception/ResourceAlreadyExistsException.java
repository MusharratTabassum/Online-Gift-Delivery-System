package com.giftsdelivery.order_info.exception;

public class ResourceAlreadyExistsException extends Exception {
    public ResourceAlreadyExistsException() {
        super("already Exists!");
    }
}
