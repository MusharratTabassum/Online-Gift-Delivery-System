package com.giftsdelivery.giftsitems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiftsItemsApplication {

    public static void main(String[] args) {
        SpringApplication.run(GiftsItemsApplication.class, args);
    }

}
